import { CheckCircle2, Clock3, XCircle } from 'lucide-react';
import { CandidateStatus } from '../types';

interface StatusIndicatorProps {
  status: CandidateStatus;
}

export function StatusIndicator({ status }: StatusIndicatorProps) {
  if (status === 'Shortlisted') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 whitespace-nowrap shrink-0">
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
        <span>Shortlisted</span>
      </span>
    );
  }

  if (status === 'Pending') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 whitespace-nowrap shrink-0">
        <Clock3 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
        <span>Pending</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-rose-700 whitespace-nowrap shrink-0">
      <XCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      <span>Rejected</span>
    </span>
  );
}
