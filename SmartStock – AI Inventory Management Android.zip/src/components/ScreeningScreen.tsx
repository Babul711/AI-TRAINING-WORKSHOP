import React, { useMemo, useState } from 'react';
import { Check, Plus, RotateCcw, Search, X } from 'lucide-react';
import { CandidateRecord, CandidateStatus } from '../types';
import { StatusIndicator } from './StatusIndicator';

interface ScreeningScreenProps {
  candidates: CandidateRecord[];
  onAddCandidate: (
    name: string,
    role: string,
    yearsExperience: number,
    skills: string
  ) => void;
  onUpdateStatus: (id: number, status: CandidateStatus) => void;
}

const STATUS_FILTERS: Array<'All' | CandidateStatus> = [
  'All',
  'Pending',
  'Shortlisted',
  'Rejected',
];

export function ScreeningScreen({
  candidates,
  onAddCandidate,
  onUpdateStatus,
}: ScreeningScreenProps) {
  const [nameInput, setNameInput] = useState('');
  const [roleInput, setRoleInput] = useState('');
  const [experienceInput, setExperienceInput] = useState('');
  const [skillsInput, setSkillsInput] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const [statusFilter, setStatusFilter] = useState<'All' | CandidateStatus>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCandidates = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return candidates.filter((c) => {
      const matchesStatus = statusFilter === 'All' || c.status === statusFilter;
      const matchesSearch =
        !query ||
        c.name.toLowerCase().includes(query) ||
        c.targetRole.toLowerCase().includes(query) ||
        c.skills.toLowerCase().includes(query);
      return matchesStatus && matchesSearch;
    });
  }, [candidates, statusFilter, searchQuery]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = nameInput.trim();
    const trimmedRole = roleInput.trim();
    const years = Number.parseInt(experienceInput.trim(), 10);
    const trimmedSkills = skillsInput.trim();

    if (!trimmedName) {
      setFormError('Candidate Name is required.');
      return;
    }
    if (!trimmedRole) {
      setFormError('Target Role is required.');
      return;
    }
    if (experienceInput.trim() === '' || Number.isNaN(years) || years < 0) {
      setFormError('Enter valid years of experience (0 or higher).');
      return;
    }
    if (!trimmedSkills) {
      setFormError('Please enter at least one key skill.');
      return;
    }

    onAddCandidate(trimmedName, trimmedRole, years, trimmedSkills);
    setNameInput('');
    setRoleInput('');
    setExperienceInput('');
    setSkillsInput('');
    setFormError(null);
    setSuccessNotice(`Added ${trimmedName} to Pending Review.`);
  };

  const clearFeedback = () => {
    if (formError) setFormError(null);
    if (successNotice) setSuccessNotice(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            Candidate Screening & Entry
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Add new applicants and update pipeline decisions in real time.
          </p>
        </div>
        <p className="text-xs font-medium text-slate-500 whitespace-nowrap shrink-0">
          Sample Data
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Part A — Interactive Input Form */}
        <section
          aria-label="Add Candidate Form"
          className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 sm:p-6"
        >
          <div className="mb-4">
            <h2 className="text-base font-semibold text-slate-900">Add New Candidate</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              New entries start in Pending status for screening.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4" noValidate>
            <div>
              <label
                htmlFor="candidate-name"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Candidate Name
              </label>
              <input
                id="candidate-name"
                type="text"
                value={nameInput}
                onChange={(e) => {
                  setNameInput(e.target.value);
                  clearFeedback();
                }}
                placeholder="e.g., Neha Sharma"
                className="w-full min-h-[42px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>

            <div>
              <label
                htmlFor="target-role"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Target Role
              </label>
              <input
                id="target-role"
                type="text"
                value={roleInput}
                onChange={(e) => {
                  setRoleInput(e.target.value);
                  clearFeedback();
                }}
                placeholder="e.g., Mobile Developer"
                className="w-full min-h-[42px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>

            <div>
              <label
                htmlFor="years-exp"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Years of Experience
              </label>
              <input
                id="years-exp"
                type="number"
                min={0}
                max={50}
                value={experienceInput}
                onChange={(e) => {
                  setExperienceInput(e.target.value);
                  clearFeedback();
                }}
                placeholder="e.g., 4"
                className="w-full min-h-[42px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>

            <div>
              <label
                htmlFor="key-skills"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Key Skills
              </label>
              <input
                id="key-skills"
                type="text"
                value={skillsInput}
                onChange={(e) => {
                  setSkillsInput(e.target.value);
                  clearFeedback();
                }}
                placeholder="e.g., Kotlin, Compose, REST APIs"
                className="w-full min-h-[42px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>

            {formError && (
              <p className="text-xs text-rose-600 font-medium" role="alert">
                {formError}
              </p>
            )}

            {successNotice && (
              <p className="text-xs text-emerald-700 font-medium" role="status">
                {successNotice}
              </p>
            )}

            <button
              type="submit"
              className="w-full min-h-[44px] px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>Submit / Add Record</span>
            </button>
          </form>
        </section>

        {/* Part B — Interactive Action List */}
        <section aria-label="Pipeline Queue" className="lg:col-span-8 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h2 className="text-base font-semibold text-slate-900 tabular-nums">
                Pipeline Queue ({filteredCandidates.length})
              </h2>

              <div className="relative w-full sm:w-64">
                <Search
                  className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search name, role, skills..."
                  aria-label="Search candidates"
                  className="w-full min-h-[40px] pl-9 pr-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>
            </div>

            <div
              className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto"
              role="tablist"
              aria-label="Filter candidates by status"
            >
              {STATUS_FILTERS.map((filter) => {
                const isActive = statusFilter === filter;
                return (
                  <button
                    key={filter}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => setStatusFilter(filter)}
                    className={`flex-1 min-h-[38px] px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 ${
                      isActive
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {filter}
                  </button>
                );
              })}
            </div>
          </div>

          {filteredCandidates.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-3">
              <p className="text-sm font-medium text-slate-800">
                No candidates match the current filter.
              </p>
              <p className="text-xs text-slate-500">
                Try clearing your search query or switching to All statuses.
              </p>
              {(statusFilter !== 'All' || searchQuery !== '') && (
                <button
                  type="button"
                  onClick={() => {
                    setStatusFilter('All');
                    setSearchQuery('');
                  }}
                  className="min-h-[40px] px-4 py-2 text-xs font-semibold text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  Clear Filters
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredCandidates.map((candidate) => (
                <article
                  key={candidate.id}
                  className="bg-white border border-slate-200 rounded-xl p-5 space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="text-base font-semibold text-slate-900">
                        {candidate.name}
                      </h3>
                      <p className="text-sm text-slate-600 mt-0.5">
                        {candidate.targetRole} ·{' '}
                        <span className="font-mono tabular-nums">
                          {candidate.yearsExperience}
                        </span>{' '}
                        yrs experience
                      </p>
                    </div>
                    <StatusIndicator status={candidate.status} />
                  </div>

                  <div className="text-xs text-slate-500 flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span className="font-medium text-slate-700">Skills:</span>
                    <span>{candidate.skills}</span>
                    <span aria-hidden="true">·</span>
                    <span>Updated {candidate.updatedAt}</span>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      disabled={candidate.status === 'Shortlisted'}
                      onClick={() => onUpdateStatus(candidate.id, 'Shortlisted')}
                      className="flex-1 sm:flex-none min-h-[42px] px-4 py-2 text-xs font-semibold rounded-lg inline-flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap disabled:opacity-45 disabled:cursor-not-allowed bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600"
                    >
                      <Check className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Approve / Shortlist</span>
                    </button>

                    <button
                      type="button"
                      disabled={candidate.status === 'Rejected'}
                      onClick={() => onUpdateStatus(candidate.id, 'Rejected')}
                      className="flex-1 sm:flex-none min-h-[42px] px-4 py-2 text-xs font-semibold rounded-lg inline-flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap disabled:opacity-45 disabled:cursor-not-allowed bg-white text-rose-700 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-600"
                    >
                      <X className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Reject</span>
                    </button>

                    {candidate.status !== 'Pending' && (
                      <button
                        type="button"
                        onClick={() => onUpdateStatus(candidate.id, 'Pending')}
                        className="min-h-[42px] px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg inline-flex items-center gap-1.5 transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400"
                      >
                        <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Reset</span>
                      </button>
                    )}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
