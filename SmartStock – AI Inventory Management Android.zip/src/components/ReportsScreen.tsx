import { Info } from 'lucide-react';
import { CandidateRecord, buildRuleBasedRecommendations } from '../types';

interface ReportsScreenProps {
  candidates: CandidateRecord[];
}

interface BreakdownBarProps {
  label: string;
  count: number;
  total: number;
  barColorClass: string;
}

function BreakdownBar({ label, count, total, barColorClass }: BreakdownBarProps) {
  const percentage = total > 0 ? Math.round((count / total) * 100) : 0;

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium text-slate-800">{label}</span>
        <span className="text-xs text-slate-500 font-mono tabular-nums">
          {count} / {total} ({percentage}%)
        </span>
      </div>
      <div
        className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden"
        role="progressbar"
        aria-valuenow={percentage}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label}
      >
        <div
          className={`h-full rounded-full transition-all duration-300 ${barColorClass}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}

export function ReportsScreen({ candidates }: ReportsScreenProps) {
  const total = candidates.length;
  const shortlisted = candidates.filter((c) => c.status === 'Shortlisted').length;
  const pending = candidates.filter((c) => c.status === 'Pending').length;
  const rejected = candidates.filter((c) => c.status === 'Rejected').length;

  const seniorCount = candidates.filter((c) => c.yearsExperience >= 5).length;
  const midCount = candidates.filter(
    (c) => c.yearsExperience >= 3 && c.yearsExperience <= 4
  ).length;
  const juniorCount = candidates.filter((c) => c.yearsExperience < 3).length;

  const recommendations = buildRuleBasedRecommendations(candidates);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            Business Summary & Recommendations
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Structured pipeline breakdown and deterministic candidate prioritization.
          </p>
        </div>
        <p className="text-xs font-medium text-slate-500 whitespace-nowrap shrink-0">
          Sample Results
        </p>
      </div>

      {/* Prominent Non-AI Disclaimer Banner */}
      <div
        className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3"
        role="note"
      >
        <Info className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" aria-hidden="true" />
        <p className="text-sm text-amber-900 font-medium leading-relaxed">
          Note: Metrics and recommendations below are generated from predefined rules and local sample data, not live AI.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Section A — Summary Breakdown */}
        <section
          aria-label="Summary Breakdown"
          className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-6"
        >
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Section A — Pipeline Breakdown
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Live status distribution across all {total} sample records.
            </p>
          </div>

          <div className="space-y-4">
            <BreakdownBar
              label="Shortlisted / Approval Rate"
              count={shortlisted}
              total={total}
              barColorClass="bg-emerald-600"
            />
            <BreakdownBar
              label="Pending Review Backlog"
              count={pending}
              total={total}
              barColorClass="bg-amber-500"
            />
            <BreakdownBar
              label="Rejected"
              count={rejected}
              total={total}
              barColorClass="bg-rose-600"
            />
          </div>

          <div className="pt-4 border-t border-slate-100 space-y-4">
            <h3 className="text-sm font-semibold text-slate-900">
              Experience Distribution (Sample Data)
            </h3>

            <BreakdownBar
              label="Senior (5+ yrs)"
              count={seniorCount}
              total={total}
              barColorClass="bg-blue-600"
            />
            <BreakdownBar
              label="Mid-Level (3–4 yrs)"
              count={midCount}
              total={total}
              barColorClass="bg-blue-500"
            />
            <BreakdownBar
              label="Early Career (0–2 yrs)"
              count={juniorCount}
              total={total}
              barColorClass="bg-slate-500"
            />
          </div>
        </section>

        {/* Section B — Rule-Based Recommendations */}
        <section aria-label="Rule-Based Recommendations" className="lg:col-span-7 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-1">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-base font-semibold text-slate-900">
                Section B — Rule-Based Recommendations
              </h2>
              <span className="text-xs text-slate-500 whitespace-nowrap">Sample Results</span>
            </div>
            <p className="text-xs text-slate-500">
              Dynamically prioritized from current screening statuses and years-of-experience thresholds.
            </p>
          </div>

          {recommendations.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl p-6 text-sm text-slate-600">
              No candidates currently match priority screening rules. Shortlist a candidate or add an applicant with 4+ years of experience in Candidate Screening.
            </div>
          ) : (
            <div className="space-y-3">
              {recommendations.map((rec) => (
                <article
                  key={rec.candidate.id}
                  className="bg-white border border-slate-200 rounded-xl p-5 space-y-2"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="text-base font-semibold text-slate-900">
                        {rec.candidate.name}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {rec.candidate.targetRole} ·{' '}
                        <span className="font-mono tabular-nums">
                          {rec.candidate.yearsExperience} yrs exp
                        </span>
                      </p>
                    </div>
                    <span
                      className={`text-xs font-semibold whitespace-nowrap shrink-0 ${
                        rec.isHighPriority ? 'text-emerald-700' : 'text-amber-700'
                      }`}
                    >
                      {rec.priorityLabel}
                    </span>
                  </div>

                  <p className="text-sm font-semibold text-blue-700">
                    {rec.actionTitle}
                  </p>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    <span className="font-medium text-slate-800">Why prioritized:</span>{' '}
                    {rec.reason}
                  </p>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
