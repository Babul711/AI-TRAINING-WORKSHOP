import { ArrowRight, CheckCircle2, Clock3, TrendingUp, Users } from 'lucide-react';
import { AppTab, CandidateRecord } from '../types';
import { StatusIndicator } from './StatusIndicator';

interface DashboardScreenProps {
  userName: string;
  userRole: string;
  candidates: CandidateRecord[];
  onNavigate: (tab: AppTab) => void;
}

export function DashboardScreen({
  userName,
  userRole,
  candidates,
  onNavigate,
}: DashboardScreenProps) {
  const totalApplicants = candidates.length;
  const shortlistedCount = candidates.filter((c) => c.status === 'Shortlisted').length;
  const pendingCount = candidates.filter((c) => c.status === 'Pending').length;
  const shortlistRate =
    totalApplicants > 0 ? Math.round((shortlistedCount / totalApplicants) * 100) : 0;

  const recentCandidates = candidates.slice(0, 2);

  return (
    <div className="space-y-6">
      {/* Greeting Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            Welcome, {userName}
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            {userRole} · Recruitment Overview
          </p>
        </div>
        <p className="text-xs font-medium text-slate-500 whitespace-nowrap shrink-0">
          Sample Business Data
        </p>
      </div>

      {/* 2x2 Summary KPI Grid */}
      <section aria-label="Pipeline KPI Summary">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 flex items-start justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-slate-500">Total Applicants</p>
              <p className="text-3xl font-bold text-slate-900 mt-1.5 font-mono tabular-nums">
                {totalApplicants}
              </p>
              <p className="text-xs text-slate-500 mt-1">Active pipeline records</p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Users className="w-5 h-5" aria-hidden="true" />
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5 flex items-start justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-slate-500">Shortlisted</p>
              <p className="text-3xl font-bold text-slate-900 mt-1.5 font-mono tabular-nums">
                {shortlistedCount}
              </p>
              <p className="text-xs text-slate-500 mt-1">Ready for panel interviews</p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5" aria-hidden="true" />
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5 flex items-start justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-slate-500">Pending Review</p>
              <p className="text-3xl font-bold text-slate-900 mt-1.5 font-mono tabular-nums">
                {pendingCount}
              </p>
              <p className="text-xs text-slate-500 mt-1">Awaiting initial screening</p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
              <Clock3 className="w-5 h-5" aria-hidden="true" />
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5 flex items-start justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-slate-500">Shortlist Rate</p>
              <p className="text-3xl font-bold text-slate-900 mt-1.5 font-mono tabular-nums">
                {shortlistRate}%
              </p>
              <p className="text-xs text-slate-500 mt-1 tabular-nums">
                {shortlistedCount} of {totalApplicants} candidates
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <TrendingUp className="w-5 h-5" aria-hidden="true" />
            </div>
          </div>
        </div>
      </section>

      {/* Recent Activity & Quick Actions Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Recent Activity Card (Latest 2 items) */}
        <section
          aria-label="Recent Activity"
          className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 sm:p-6"
        >
          <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <h2 className="text-base font-semibold text-slate-900">Recent Activity</h2>
            <span className="text-xs text-slate-500">Latest 2 · Sample Data</span>
          </div>

          {recentCandidates.length === 0 ? (
            <div className="py-8 text-center">
              <p className="text-sm text-slate-500">No candidate records available yet.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentCandidates.map((candidate) => (
                <div
                  key={candidate.id}
                  className="py-4 first:pt-4 last:pb-1 flex items-center justify-between gap-4"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900 truncate">
                      {candidate.name}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5 truncate">
                      {candidate.targetRole} ·{' '}
                      <span className="tabular-nums">{candidate.yearsExperience} yrs exp</span> ·{' '}
                      {candidate.updatedAt}
                    </p>
                  </div>
                  <StatusIndicator status={candidate.status} />
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Quick Actions Card */}
        <section
          aria-label="Quick Actions"
          className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-4"
        >
          <div>
            <h2 className="text-base font-semibold text-slate-900">Quick Actions</h2>
            <p className="text-xs text-slate-500 mt-1">
              Jump directly to candidate entry or pipeline recommendations.
            </p>
          </div>

          <div className="space-y-3">
            <button
              type="button"
              onClick={() => onNavigate('screening')}
              className="w-full min-h-[44px] px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg inline-flex items-center justify-between gap-2 transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
            >
              <span>Candidate Screening & Entry</span>
              <ArrowRight className="w-4 h-4 shrink-0" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={() => onNavigate('reports')}
              className="w-full min-h-[44px] px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 text-sm font-medium rounded-lg inline-flex items-center justify-between gap-2 transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400"
            >
              <span>Business Summary & Recommendations</span>
              <ArrowRight className="w-4 h-4 text-slate-500 shrink-0" aria-hidden="true" />
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
