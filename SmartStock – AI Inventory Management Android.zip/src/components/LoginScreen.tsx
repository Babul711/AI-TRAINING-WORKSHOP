import React, { useState } from 'react';
import { ArrowRight, Briefcase, UserCheck } from 'lucide-react';
import { AVAILABLE_ROLES } from '../types';

interface LoginScreenProps {
  onLogin: (userName: string, role: string) => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [userName, setUserName] = useState('');
  const [selectedRole, setSelectedRole] = useState<string>(AVAILABLE_ROLES[0]);
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = userName.trim();
    if (!trimmed) {
      setValidationError('Please enter your name or staff ID, or continue as Guest Manager.');
      return;
    }
    onLogin(trimmed, selectedRole);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between px-4 py-8 sm:px-6 lg:px-8">
      <div className="max-w-5xl w-full mx-auto my-auto grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
        {/* Left Brand & Value Proposition */}
        <div className="lg:col-span-6 space-y-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-blue-600 text-white shadow-sm">
            <Briefcase className="w-6 h-6" aria-hidden="true" />
          </div>

          <div className="space-y-3">
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 text-balance">
              TalentFlow HR
            </h1>
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-lg">
              Streamlining candidate screening and recruitment pipeline tracking for HR managers and business operations leads.
            </p>
          </div>

          <div className="pt-2 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-lg">
            <div>
              <p className="text-xs font-medium text-slate-500">Live Metrics</p>
              <p className="text-sm font-semibold text-slate-900 mt-0.5">2x2 Pipeline KPIs</p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Screening Queue</p>
              <p className="text-sm font-semibold text-slate-900 mt-0.5">Instant Actions</p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Rule Insights</p>
              <p className="text-sm font-semibold text-slate-900 mt-0.5">Priority Triage</p>
            </div>
          </div>
        </div>

        {/* Right Sign-In Card */}
        <div className="lg:col-span-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm">
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-slate-900">Workspace Sign In</h2>
              <p className="text-sm text-slate-500 mt-1">
                Enter your staff identifier and select your operational role to begin.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5" noValidate>
              <div>
                <label
                  htmlFor="staff-name"
                  className="block text-sm font-medium text-slate-700 mb-1.5"
                >
                  User Name / Staff ID
                </label>
                <input
                  id="staff-name"
                  type="text"
                  value={userName}
                  onChange={(e) => {
                    setUserName(e.target.value);
                    if (validationError && e.target.value.trim()) {
                      setValidationError(null);
                    }
                  }}
                  placeholder="e.g., Maya Kapoor or HR-104"
                  className={`w-full min-h-[44px] px-3.5 py-2.5 text-sm bg-white border rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 transition-colors ${
                    validationError ? 'border-rose-500' : 'border-slate-300'
                  }`}
                />
                {validationError && (
                  <p className="mt-1.5 text-xs text-rose-600 font-medium" role="alert">
                    {validationError}
                  </p>
                )}
              </div>

              <div>
                <span className="block text-sm font-medium text-slate-700 mb-2">
                  Role / Department
                </span>
                <div className="grid grid-cols-2 gap-2" role="group" aria-label="Select Role">
                  {AVAILABLE_ROLES.map((role) => {
                    const isSelected = selectedRole === role;
                    return (
                      <button
                        key={role}
                        type="button"
                        onClick={() => setSelectedRole(role)}
                        className={`min-h-[44px] px-3 py-2 text-xs sm:text-sm font-medium rounded-lg border text-left transition-colors whitespace-nowrap truncate focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 ${
                          isSelected
                            ? 'bg-blue-50 border-blue-600 text-blue-700'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                        }`}
                      >
                        {role}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="pt-2 space-y-2.5">
                <button
                  type="submit"
                  className="w-full min-h-[44px] px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
                >
                  <span>Sign In / Enter Workspace</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </button>

                <button
                  type="button"
                  onClick={() => onLogin('Guest Manager', selectedRole)}
                  className="w-full min-h-[44px] px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-sm font-medium rounded-lg inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400"
                >
                  <UserCheck className="w-4 h-4 text-slate-500" aria-hidden="true" />
                  <span>Continue as Guest Manager</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <footer className="max-w-5xl w-full mx-auto pt-8 text-center">
        <p className="text-xs text-slate-500">
          Prototype Mode: Uses local sample data (no live backend authentication).
        </p>
      </footer>
    </div>
  );
}
