/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { BarChart3, ClipboardCheck, LayoutDashboard, LogOut } from 'lucide-react';
import { DashboardScreen } from './components/DashboardScreen';
import { LoginScreen } from './components/LoginScreen';
import { ReportsScreen } from './components/ReportsScreen';
import { ScreeningScreen } from './components/ScreeningScreen';
import {
  AppTab,
  CandidateRecord,
  CandidateStatus,
  INITIAL_CANDIDATES,
  UserSession,
} from './types';

const NAV_ITEMS: Array<{
  id: AppTab;
  label: string;
  icon: typeof LayoutDashboard;
}> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'screening', label: 'Screening', icon: ClipboardCheck },
  { id: 'reports', label: 'Reports', icon: BarChart3 },
];

export default function App() {
  const [session, setSession] = useState<UserSession | null>(null);
  const [activeTab, setActiveTab] = useState<AppTab>('dashboard');
  const [candidates, setCandidates] = useState<CandidateRecord[]>(INITIAL_CANDIDATES);
  const [nextId, setNextId] = useState<number>(INITIAL_CANDIDATES.length + 1);

  const handleLogin = (userName: string, role: string) => {
    setSession({ userName, role });
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setSession(null);
    setActiveTab('dashboard');
  };

  const handleAddCandidate = (
    name: string,
    targetRole: string,
    yearsExperience: number,
    skills: string
  ) => {
    const newRecord: CandidateRecord = {
      id: nextId,
      name,
      targetRole,
      yearsExperience,
      skills,
      status: 'Pending',
      updatedAt: 'Just now',
    };
    setNextId((prev) => prev + 1);
    setCandidates((prev) => [newRecord, ...prev]);
  };

  const handleUpdateStatus = (id: number, status: CandidateStatus) => {
    setCandidates((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, status, updatedAt: 'Just now' } : item
      )
    );
  };

  if (!session) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* Top Bar */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            TalentFlow HR
          </button>

          <nav
            className="hidden md:flex items-center gap-8"
            aria-label="Primary Navigation"
          >
            {NAV_ITEMS.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`py-1.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 ${
                    isActive
                      ? 'border-blue-600 text-blue-700 font-semibold'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-4 shrink-0">
            <span className="hidden sm:inline text-xs font-medium text-slate-600 truncate max-w-[180px]">
              {session.userName}
            </span>
            <button
              type="button"
              onClick={handleLogout}
              className="min-h-[38px] px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
            >
              <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 pb-24 md:pb-10">
        {activeTab === 'dashboard' && (
          <DashboardScreen
            userName={session.userName}
            userRole={session.role}
            candidates={candidates}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'screening' && (
          <ScreeningScreen
            candidates={candidates}
            onAddCandidate={handleAddCandidate}
            onUpdateStatus={handleUpdateStatus}
          />
        )}

        {activeTab === 'reports' && <ReportsScreen candidates={candidates} />}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav
        className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-sm border-t border-slate-200 grid grid-cols-3 h-14"
        aria-label="Mobile Bottom Navigation"
      >
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-blue-600 ${
                isActive ? 'text-blue-600 font-semibold' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" aria-hidden="true" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
