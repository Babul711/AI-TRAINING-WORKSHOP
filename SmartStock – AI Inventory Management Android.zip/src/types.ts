export type AppTab = 'dashboard' | 'screening' | 'reports';

export type CandidateStatus = 'Pending' | 'Shortlisted' | 'Rejected';

export interface CandidateRecord {
  id: number;
  name: string;
  targetRole: string;
  yearsExperience: number;
  skills: string;
  status: CandidateStatus;
  updatedAt: string;
}

export interface RecommendationItem {
  candidate: CandidateRecord;
  priorityLabel: string;
  actionTitle: string;
  reason: string;
  isHighPriority: boolean;
}

export interface UserSession {
  userName: string;
  role: string;
}

export const AVAILABLE_ROLES = [
  'HR Manager',
  'Operations Lead',
  'Tech Recruiter',
  'Hiring Lead',
] as const;

export const INITIAL_CANDIDATES: CandidateRecord[] = [
  {
    id: 1,
    name: 'Aarav Mehta',
    targetRole: 'Senior Android Engineer',
    yearsExperience: 6,
    skills: 'Kotlin, Jetpack Compose, Coroutines',
    status: 'Shortlisted',
    updatedAt: 'Today, 09:40 AM',
  },
  {
    id: 2,
    name: 'Priya Nair',
    targetRole: 'HR Operations Specialist',
    yearsExperience: 4,
    skills: 'HRIS, Onboarding, Workforce Analytics',
    status: 'Pending',
    updatedAt: 'Today, 09:15 AM',
  },
  {
    id: 3,
    name: 'Rohan Kulkarni',
    targetRole: 'Product Manager',
    yearsExperience: 5,
    skills: 'Roadmapping, Agile, SQL, B2B SaaS',
    status: 'Shortlisted',
    updatedAt: 'Yesterday',
  },
  {
    id: 4,
    name: 'Sneha Iyer',
    targetRole: 'UX Researcher',
    yearsExperience: 2,
    skills: 'Usability Testing, Figma, Prototyping',
    status: 'Shortlisted',
    updatedAt: 'Yesterday',
  },
  {
    id: 5,
    name: 'Vikram Joshi',
    targetRole: 'Backend Engineer',
    yearsExperience: 1,
    skills: 'Java, Spring Boot, PostgreSQL',
    status: 'Rejected',
    updatedAt: '2 days ago',
  },
  {
    id: 6,
    name: 'Ananya Verma',
    targetRole: 'Business Operations Analyst',
    yearsExperience: 4,
    skills: 'Excel, Power BI, Process Mapping',
    status: 'Pending',
    updatedAt: '2 days ago',
  },
];

export function buildRuleBasedRecommendations(
  candidates: CandidateRecord[]
): RecommendationItem[] {
  const results: RecommendationItem[] = [];

  for (const candidate of candidates) {
    if (candidate.status === 'Shortlisted' && candidate.yearsExperience >= 3) {
      results.push({
        candidate,
        priorityLabel: 'High Priority',
        actionTitle: 'Fast-Track to Panel Interview',
        reason: `Status is Shortlisted and candidate has ${candidate.yearsExperience} yrs experience (>= 3 yrs threshold).`,
        isHighPriority: true,
      });
    } else if (candidate.status === 'Pending' && candidate.yearsExperience >= 4) {
      results.push({
        candidate,
        priorityLabel: 'Review Today',
        actionTitle: 'Prioritize Initial Screening',
        reason: `Still Pending review despite ${candidate.yearsExperience} yrs senior experience in ${candidate.skills}.`,
        isHighPriority: false,
      });
    } else if (candidate.status === 'Shortlisted' && candidate.yearsExperience < 3) {
      results.push({
        candidate,
        priorityLabel: 'Associate Track',
        actionTitle: 'Schedule Practical Skills Check',
        reason: `Status is Shortlisted with ${candidate.yearsExperience} yrs experience (< 3 yrs); verify role readiness.`,
        isHighPriority: true,
      });
    }
  }

  return results;
}
